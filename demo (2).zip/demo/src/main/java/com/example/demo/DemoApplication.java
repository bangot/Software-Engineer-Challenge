package com.example.demo;

import org.apache.commons.cli.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		// Kiểm tra nếu có đối số CLI
		if (args.length > 0 && (args[0].equals("--input") || args[0].equals("-i") || args[0].equals("--help") || args[0].equals("-h"))) {
			// Chạy CLI
			runCli(args);
		} else {
			// Chạy web API
			SpringApplication.run(DemoApplication.class, args);
		}
	}

	private static void runCli(String[] args) {
		Options options = new Options();
		options.addOption("i", "input", true, "Input CSV file path");
		options.addOption("o", "output", true, "Output directory path");
		options.addOption("h", "help", false, "Show help");

		CommandLineParser parser = new DefaultParser();
		HelpFormatter formatter = new HelpFormatter();
		CommandLine cmd = null;

		try {
			cmd = parser.parse(options, args);

			if (cmd.hasOption("h")) {
				formatter.printHelp("aggregator", options);
				return;
			}

			String inputFile = cmd.getOptionValue("i");
			String outputDir = cmd.getOptionValue("o", "results");

			if (inputFile == null) {
				System.err.println("Error: Input file is required");
				formatter.printHelp("aggregator", options);
				return;
			}

			// Create output directory if not exists
			java.nio.file.Files.createDirectories(java.nio.file.Paths.get(outputDir));

			long startTime = System.currentTimeMillis();
			System.out.println("Processing file: " + inputFile);

			// Process CSV
			CampaignAggregator aggregator = new CampaignAggregator();
			aggregator.processCSV(inputFile);

			// Save results
			String top10CtrPath = outputDir + "/top10_ctr.csv";
			String top10CpaPath = outputDir + "/top10_cpa.csv";

			aggregator.saveTop10CTR(top10CtrPath);
			aggregator.saveTop10CPA(top10CpaPath);

			long endTime = System.currentTimeMillis();
			System.out.println("✓ Results saved to: " + outputDir);
			System.out.println("  - " + top10CtrPath);
			System.out.println("  - " + top10CpaPath);
			System.out.println("Processing time: " + (endTime - startTime) + " ms");

		} catch (ParseException e) {
			System.err.println("Parse error: " + e.getMessage());
			formatter.printHelp("aggregator", options);
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		}
	}
}