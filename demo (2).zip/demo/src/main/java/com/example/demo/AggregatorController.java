package com.example.demo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/aggregator")
public class AggregatorController {

    @PostMapping("/process")
    public ResponseEntity<byte[]> processCsv(@RequestParam("file") MultipartFile file) {
        try {
            // Lưu file tạm
            Path tempFile = Files.createTempFile("uploaded", ".csv");
            file.transferTo(tempFile.toFile());

            // Xử lý
            CampaignAggregator aggregator = new CampaignAggregator();
            aggregator.processCSV(tempFile.toString());

            // Lấy top 10
            List<CampaignData> topCtr = aggregator.getTop10CTR();
            List<CampaignData> topCpa = aggregator.getTop10CPA();

            // Ghi ra file CSV
            Path outputFile = Files.createTempFile("aggregated_result", ".csv");
            writeCsv(outputFile, topCtr, topCpa);

            // Đọc file CSV thành byte[]
            byte[] data = Files.readAllBytes(outputFile);

            // Trả về file CSV để tải xuống
            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=aggregated_result.csv")
                    .header("Content-Type", "text/csv")
                    .body(data);

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(("Error: " + e.getMessage()).getBytes());
        }
    }

    private void writeCsv(Path file, List<CampaignData> topCtr, List<CampaignData> topCpa) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Top 10 CTR ===\n");
        sb.append("campaign_id,total_impressions,total_clicks,total_spend,total_conversions,CTR,CPA\n");
        for (CampaignData c : topCtr) {
            sb.append(String.format("%s,%d,%d,%.2f,%d,%.4f,%.2f\n",
                    c.getCampaignId(), c.getTotalImpressions(), c.getTotalClicks(),
                    c.getTotalSpend(), c.getTotalConversions(), c.getCTR(), c.getCPA()));
        }

        sb.append("\n=== Top 10 CPA ===\n");
        sb.append("campaign_id,total_impressions,total_clicks,total_spend,total_conversions,CTR,CPA\n");
        for (CampaignData c : topCpa) {
            sb.append(String.format("%s,%d,%d,%.2f,%d,%.4f,%.2f\n",
                    c.getCampaignId(), c.getTotalImpressions(), c.getTotalClicks(),
                    c.getTotalSpend(), c.getTotalConversions(), c.getCTR(), c.getCPA()));
        }

        Files.writeString(file, sb.toString());
    }





}