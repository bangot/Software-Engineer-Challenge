package com.example.demo;

public class CampaignData {
    private String campaignId;
    private long totalImpressions;
    private long totalClicks;
    private double totalSpend;
    private long totalConversions;

    public CampaignData(String campaignId) {
        this.campaignId = campaignId;
    }

    // Getters & Setters
    public String getCampaignId() { return campaignId; }
    public long getTotalImpressions() { return totalImpressions; }
    public void setTotalImpressions(long value) { this.totalImpressions = value; }
    public long getTotalClicks() { return totalClicks; }
    public void setTotalClicks(long value) { this.totalClicks = value; }
    public double getTotalSpend() { return totalSpend; }
    public void setTotalSpend(double value) { this.totalSpend = value; }
    public long getTotalConversions() { return totalConversions; }
    public void setTotalConversions(long value) { this.totalConversions = value; }

    // Calculated metrics
    public double getCTR() {
        return totalImpressions > 0 ? (double) totalClicks / totalImpressions : 0;
    }

    public Double getCPA() {
        return totalConversions > 0 ? totalSpend / totalConversions : null;
    }

    public void addRow(long impressions, long clicks, double spend, long conversions) {
        this.totalImpressions += impressions;
        this.totalClicks += clicks;
        this.totalSpend += spend;
        this.totalConversions += conversions;
    }
}