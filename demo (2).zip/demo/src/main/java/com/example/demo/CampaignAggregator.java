package com.example.demo;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;

public class CampaignAggregator {
//    private Map<String, CampaignData> campaignMap = new HashMap<>();


    private final ConcurrentHashMap<String, CampaignData> campaignMap = new ConcurrentHashMap<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    public void processCSV(String inputFile) throws IOException, CsvValidationException, InterruptedException {
        try (CSVReader reader = new CSVReader(new FileReader(inputFile))) {
            String[] nextLine;
            boolean isHeader = true;
            List<String[]> batch = new ArrayList<>();
            int batchSize = 10_000;

            while ((nextLine = reader.readNext()) != null) {
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                batch.add(nextLine);

                if (batch.size() >= batchSize) {
                    submitBatch(new ArrayList<>(batch));
                    batch.clear();
                }
            }
            // xử lý batch cuối cùng
            if (!batch.isEmpty()) {
                submitBatch(batch);
            }
        }

        // chờ tất cả task hoàn thành
        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.HOURS);
    }

    private void submitBatch(List<String[]> batch) {
        executor.submit(() -> {
            for (String[] row : batch) {
                try {
                    String campaignId = row[0].trim();
                    long impressions = Long.parseLong(row[2].trim());
                    long clicks = Long.parseLong(row[3].trim());
                    double spend = Double.parseDouble(row[4].trim());
                    long conversions = Long.parseLong(row[5].trim());

                    campaignMap.computeIfAbsent(campaignId, CampaignData::new)
                            .addRow(impressions, clicks, spend, conversions);
                } catch (Exception e) {
                    System.err.println("Warning: Skipping malformed row: " + Arrays.toString(row));
                }
            }
        });
    }


    public void saveTop10CTR(String outputFile) throws IOException {
        List<CampaignData> sorted = campaignMap.values().stream()
                .sorted((a, b) -> Double.compare(b.getCTR(), a.getCTR()))
                .limit(10)
                .collect(Collectors.toList());

        writeToCSV(outputFile, sorted);
    }

    public void saveTop10CPA(String outputFile) throws IOException {
        List<CampaignData> sorted = campaignMap.values().stream()
                .filter(c -> c.getTotalConversions() > 0) // Exclude zero conversions
                .sorted((a, b) -> {
                    Double cpaA = a.getCPA();
                    Double cpaB = b.getCPA();
                    if (cpaA == null) return 1;
                    if (cpaB == null) return -1;
                    return cpaA.compareTo(cpaB);
                })
                .limit(10)
                .collect(Collectors.toList());

        writeToCSV(outputFile, sorted);
    }

    private void writeToCSV(String outputFile, List<CampaignData> data) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {
            // Header
            writer.println("campaign_id,total_impressions,total_clicks,total_spend,total_conversions,CTR,CPA");

            // Data rows
            for (CampaignData campaign : data) {
                Double cpa = campaign.getCPA();
                String cpaStr = cpa != null ? String.format("%.2f", cpa) : "null";
                writer.printf("%s,%d,%d,%.2f,%d,%.4f,%s%n",
                        campaign.getCampaignId(),
                        campaign.getTotalImpressions(),
                        campaign.getTotalClicks(),
                        campaign.getTotalSpend(),
                        campaign.getTotalConversions(),
                        campaign.getCTR(),
                        cpaStr);
            }
        }
    }

    public List<CampaignData> getTop10CTR() {
        return campaignMap.values().stream()
                .sorted((a, b) -> Double.compare(b.getCTR(), a.getCTR()))
                .limit(10)
                .collect(Collectors.toList());
    }

    public List<CampaignData> getTop10CPA() {
        return campaignMap.values().stream()
                .filter(c -> c.getTotalConversions() > 0)
                .sorted((a, b) -> {
                    Double cpaA = a.getCPA();
                    Double cpaB = b.getCPA();
                    if (cpaA == null) return 1;
                    if (cpaB == null) return -1;
                    return cpaA.compareTo(cpaB);
                })
                .limit(10)
                .collect(Collectors.toList());
    }
}